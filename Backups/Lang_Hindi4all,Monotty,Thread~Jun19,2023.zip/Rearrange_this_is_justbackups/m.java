class Main1 {
public static void main(String[] arga )
{ 
	Hindi4all r=new Hindi4all("a.h4j");
}
}/*I have a Website serving an online code editor for a programming language.
I am repeatedly getting  an error:
Needs Attention:- 
Google-served ads on screens without publisher-content:

We do not allow Google-served ads on screens:
without content or with low value content
that are under construction, that are used for alerts, navigation or other behavioral purposes.

I have the code editor working fine and also indexed it on google search console successfully.
I don't know why my site is getting recognized as low valued content .
The code editor works fine and I have the documentation on another site for the programming language on other site .(The editor is the one expected to have ads not the documentation).
The code editor on my Site independently runs java programs and also the documented  programming  language (one small issue is that the code editor independently runs java programs but runs the code of documented programming language only on redirection from the documentation page , which is as expected/intented ).

I would like to show the working of the programming language in a video call to the officials for approval


  

*/