<html>
    <head>
        <script>

function SEND(){
const url = 'https://prathameshbhagat.000webhostapp.com/m/post.php';

const data = "N="+document.getElementsByName('N')[0].value;

const response =  fetch(url, {
    method: 'POST',
    headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: data,
});
    document.getElementsByName('label')[0].innerHTML=document.getElementsByName('N')[0].value;
}
	
</script>
        </head>
    
    <body>
        <form name="f"action="post.php" method="post">
            <input type="number" name="N" value="N"></input>
            <input type=button onclick="SEND()" value=SUBMIT></button><br> <H1 name=label></h1>
            </form>
    </body>
    </html>