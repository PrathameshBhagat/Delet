# My-Repo
Created in 2022
This is collection of some files which have codes that help revision of syntaxes and basic functionality 
of a languages  used .
It has mini programs that explain workflow of programming languages in quickest way possible.
These codes were created while learning languages and uploaded to save them in the easiest way possible.
