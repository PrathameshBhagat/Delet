class Person:
    def __init__(self , name , city ):
        self.name = name
        self.city = city
    def display(self):
        print(f"Name = {self.name}")
        print(f"City = {self.city}")
class Student(Person):
    def __init__(self , name  , city , roll , dept ):
        super().__init__(name , city)
        self.roll = roll
        self.dept = dept
    def display(self):
        super().display()
        print(f"Roll = {self.roll}")
        print(f"Deptartment = {self.dept}")
class Teacher(Person):
    def __init__(self , name  , city ,  desig , dept ):
        super().__init__(name , city)
        self.desig = desig
        self.dept = dept
    def display(self):
        super().display()
        print(f"Designation = {self.desig}")
        print(f"Dept = {self.dept}")
PVB= Student("Prathamesh " , "Wardha"  , 245 , "computer")
PVB.display()
print("\n**************************************************\n")
teacher = Teacher("Teacher 1" , "Wardha"  , "Assisstant Professor" , "computer")
teacher.display()
