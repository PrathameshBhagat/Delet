import csv
with open ("Books.csv", "w" , newline='') as F1:
    csvwriter = csv.writer(F1)
    while True:
        op = input("Enter y to add data and n to quit = ")
        if (op == 'y'):
            bookno = input("Enter Your Book No : ") 
            bname = input("Enter Your Name : ") 
            bauthor = input("Enter Author Name : ") 
            bpublisher = input("Enter Publisher Name : ") 
            bprice = int(input("Enter Price : "))   
            csvwriter.writerow([bookno, bname , bauthor , bpublisher , bprice])
        else:
            break
F1.close()
F1 = open ("Books.csv","r")
csvreader = csv.reader(F1 , delimiter='@')
count=0
while True:
    try:
        for row in csvreader:
            count+=1
            print(row)
        break
    except EOFError:
        break
print("Total No of Records = ", count)
F1.close()
