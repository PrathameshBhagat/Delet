import csv
with open ("employee.csv", "w" , newline='') as F1:
    writer = csv.writer(F1)
    while True:
        op = input("Enter y to add data and n to quit = ")
        if (op == 'y'):
            emp = input("Enter Emp = ")
            name = input ("Enter Customer Name : ")
            salary = int (input("Enter Salary : "))
            writer.writerow([emp,name,salary])
        else:
            break
F1.close()
F1 = open ("employee.csv","r")
reader = csv.reader(F1 , delimiter=',')
while True:
    try:
        for row in reader:
            if( int(row[2]) > 800000 ):
                print(row)
        break
    except EOFError:
        print("No Entry Found")
        break
F1.close()                         
