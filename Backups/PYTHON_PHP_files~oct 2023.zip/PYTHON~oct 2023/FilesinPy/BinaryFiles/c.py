import pickle
with open ("sports.dat", "wb") as F1:
    while True:
        op = input("Enter y to add data and n to quit = ")
        if (op == 'y'):
            event = input ("Enter Event Name : ")
            location = input ("Enter Location : ")
            participantNo = int (input("Enter Participant No. : "))
            pickle.dump([event,location,participantNo], F1)
        else:
            break
F1 = open ("sports.dat","rb")
dict = {}
while True:
    try:
        l = pickle.load(F1)
        dict.update({l[0]:l[2]})

        print(dict)
    except EOFError:
        break
