import pickle
with open ("customer.dat", "wb") as F1:
    while True:
        op = input("Enter y to add data and n to quit = ")
        if (op == 'y'):
            name = input ("Enter Custmer Name : ")
            city = input ("Enter Your City : ")
            amount = int (input("Enter Amount : "))
            pickle.dump([city,name,amount], F1)
        else :
            break
F1 = open ("customer.dat","rb")
while True:
    try:
        l = pickle.load(F1)
        if (l[0].lower()=="delhi"):
            print(l)
    except EOFError:
        break
F1.close()
