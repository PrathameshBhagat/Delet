f = open("Demo.txt" , "w")
lines = [ "Hello  i am Prathamesh\n" , "232\n"]
f.writelines(lines)
f.close()
f = open("Demo.txt" , "r")
print(f.readlines())
f.close()
