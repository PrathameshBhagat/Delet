f = open("Demo.txt" , "r")
word = "python"
wordData = f.read()
w = wordData.split()
wordCount = 0
for i in w:
    if i == word :
        wordCount = wordCount + 1
if wordCount == 0 :
    print("Word not Found")
else:
    print("There are " , wordCount , " word in file")    
f.close()
