<?php  
echo "Enter The Percentage\n";
$i = readline();  
if($i>60)
{
 echo "You Recieved First Division";
} 
else if($i<=59&&$i>=45)
{
 echo "You Recieved Second Division";
 }
else if($i<=44&&$i>=33)
{
 echo "You Recieved Third Division";
}
else if($i<=32)
{ 
echo "You HAVE failed Please Try again";  
}
?>  
